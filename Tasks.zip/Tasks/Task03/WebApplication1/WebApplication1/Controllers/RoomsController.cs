﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class RoomsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
