﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class AccountController : Controller
    {


        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(IFormCollection form)
        {
            string name = form["Name"];
            string email = form["Email"];
            string password = form["Password"];
            string confirmPassword = form["ConfirmPassword"];

            if (password != confirmPassword)
            {
                ViewBag.Error = "Password and Confirm Password do not match";
                return View();
            }

            TempData["Name"] = name;
            TempData["Email"] = email;
            TempData["Password"] = password;

            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Login()
        {
            TempData.Keep();
            return View();
        }

        [HttpPost]
        public IActionResult Login(IFormCollection form)
        {
            string email = form["Email"];
            string password = form["Password"];

            string registeredEmail = TempData["Email"]?.ToString();
            string registeredPassword = TempData["Password"]?.ToString();

            TempData.Keep();

            if (email == registeredEmail && password == registeredPassword)
            {
                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Invalid email or password";
            return View();
        }

    }
}
